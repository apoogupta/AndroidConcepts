package com.example.viewpager;

public class ReadMe {
    //https://androidwave.com/viewpager2-with-tablayout-android-example/

    
}
